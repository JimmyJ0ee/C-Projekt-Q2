Setup (Elemente, welche im Ordner vorhanden sein müssen):
	- '.file_test_win.c' als ausführbare exe kompiliert
	- '.time.txt' als Datei, welche die gebuchten Uhrzeiten speichert

Programm:
	- eingelesen werden txt-Dateien
	- diese werden außerhalb (z.B. auf dem Desktop) erstellt und dann einfach eingefügt
	- Dateien werden mit 'a_' markiert, wenn nicht valide
	- wenn valide, werden sie nach 'name'_'uhrzeit'.txt benannt
	- wenn strg+c:
		- die vorhandenen validen Dateien werden zufällig mit positiv/negativ versehen
		- eine Datei für das Gesundheitsamt wird automatisch angelegt und befüllt

beide teile des Programms haben getrennt funktioniert, noch vorhandene Probleme nach zusammenführen:
	- mit einer Datei, welche hinzugefügt und entfernt wird funktioniert das Programm
	- werden mehrere Dateien in den Ordner eingefügt, passieren komische Dinge, wie das einfach andere Dateien mit komischen Namen erstellt werden etc.
	- vor der Abgabe leider keine Zeit mehr gehabt, sich nochmal intensiv genug damit zu befassen